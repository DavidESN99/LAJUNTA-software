import { useState } from "react";

export default function App() {
  const [mensaje, setMensaje] = useState("Bienvenido a LA JUNTA resto-bar 🍕🥂");

  return (
    <main className="min-h-screen bg-black text-white flex flex-col justify-center items-center p-4">
      <h1 className="text-4xl font-bold mb-4 text-center">{mensaje}</h1>
      <p className="text-lg text-center max-w-xl">
        Este es el sistema web oficial de LA JUNTA. Aquí se manejarán los pedidos,
        cocina, stock y ventas en tiempo real. ¡Vamos con todo! 💪
      </p>
    </main>
  );
}
